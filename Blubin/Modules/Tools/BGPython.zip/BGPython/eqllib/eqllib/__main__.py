"""Command line entry point for python -m eqllib."""
from .main import normalize_main

normalize_main()
