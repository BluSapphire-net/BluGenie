{% set source=sources['Microsoft Sysmon'] %}
{% include "data-source.rst" %}