{% set source=sources['MITRE Cyber Analytics Repository'] %}
{% include "data-source.rst" %}