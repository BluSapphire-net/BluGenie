=========
License
=========

.. include:: ../LICENSE

.. note::
    The `Event Query Language <https://github.com/endgameinc/eql>`_ has an `AGPL License <https://github.com/endgameinc/eql/tree/master/LICENSE>`_
