"""Unit tests for the EQL analytics library."""
